/*
  AUTO HAVEN INVENTORY
  Add a new car by copying one car object below and changing its details.
  Keep every car inside the CARS = [ ... ] list.
  Prices are in Canadian dollars (CAD). Use a direct image URL for "image".
*/

const STORE = {
  phone: "+16045550123",          // Replace with your dealership phone number
  phoneDisplay: "(604) 555-0123", // How the phone number appears on the website
  email: "info@autohaven.ca",     // Replace with your dealership email
  location: "Surrey, BC"          // Replace with your dealership location
};

const CARS = [
  {
    id: "car-001",
    year: 2021,
    make: "Toyota",
    model: "Camry",
    trim: "SE • 4-Door Sedan",
    price: 24999,
    km: 58200,
    transmission: "Automatic",
    fuel: "Gasoline",
    location: "Surrey, BC",
    badge: "Featured",
    image: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=1000&q=85",
    description: "Comfortable, reliable and ready for the road. Contact Auto Haven for more information or to arrange a viewing."
  },
  {
    id: "car-002",
    year: 2020,
    make: "Honda",
    model: "Civic",
    trim: "Sport • Sedan",
    price: 21999,
    km: 64500,
    transmission: "Automatic",
    fuel: "Gasoline",
    location: "Surrey, BC",
    badge: "Popular",
    image: "https://images.unsplash.com/photo-1606152421802-db97b9c7a11b?auto=format&fit=crop&w=1000&q=85",
    description: "A practical daily driver with a sporty look. Contact us to confirm availability and vehicle details."
  },
  {
    id: "car-003",
    year: 2019,
    make: "BMW",
    model: "3 Series",
    trim: "330i • Sedan",
    price: 23999,
    km: 78900,
    transmission: "Automatic",
    fuel: "Gasoline",
    location: "Surrey, BC",
    badge: "",
    image: "https://images.unsplash.com/photo-1555215695-3004980ad0?auto=format&fit=crop&w=1000&q=85",
    description: "A premium sedan with a refined interior and enjoyable drive. Contact us for more details."
  }
];
