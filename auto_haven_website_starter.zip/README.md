# Auto Haven website starter

## Publish it with GitHub Pages

1. Sign in to GitHub and click **New repository**.
2. Name it `auto-haven` and choose **Public**.
3. Create the repository.
4. On the repository page, click **Add file → Upload files**.
5. Upload both `index.html` and `cars.js` from this folder.
6. Click **Commit changes**.
7. Open **Settings → Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**.
9. Choose branch **main** and folder **/(root)**, then click **Save**.
10. Wait a minute or two. GitHub will show your website link in the Pages section.

## How to add a car

1. Open `cars.js` in your GitHub repository.
2. Click the pencil icon to edit it.
3. Copy one complete car object inside the `CARS` list.
4. Paste it after the last car, add a comma between objects, and change the details.
5. Use a unique `id` for every car (example: `car-004`).
6. Click **Commit changes**. Your website will update after GitHub Pages rebuilds.

## Important before going live

- In `cars.js`, replace the sample phone number, email, and location with the dealership's real contact details.
- Replace sample inventory with vehicles that are actually for sale. Verify each price, mileage, condition, and description.
- Replace sample image links with photos you own or have permission to use. Use direct image URLs.
- GitHub Pages is static hosting. This starter lets you add inventory by editing `cars.js`; it does not include a private login or admin dashboard. Anyone with repository edit access can change the listings.
- Add your dealership's required business, privacy, and advertising information before using it commercially.
